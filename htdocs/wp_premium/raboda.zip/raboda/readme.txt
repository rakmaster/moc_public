
Feb/10/2014: Released version 1.0
	-	You need read instruction in documentation folder
	
24/April/2015: Updated to version 1.1
	- Update the TGM-Plugin-Activation to version 2.4.1
	- Update the WooCommerce cart template to version 2.3.8
	- Update product price HTML
	- Update shopping cart hover event (js/theme.js)
	-------------------------------
	Updated details:
		- Updated "class-tgm-plugin-activation.php"
		- Updated "woocommerce/cart/cart.php"
		- Updated "functions.php"
		- Updated "js/theme.js"
	-------------------------------
	
26/June/2015: Updated to version 1.5
	- Fixed the page title
	- Updated the WooCommerce template
	- Updated TGM-Plugin-Activation plugin to 2.4.2 version
	- Fixed text domain (change 'woocommerce' to 'roadthemes')
	- Fixed SSL images
	- Updated plugin "RoadThemes Helper" (delete & reinstall to update)
	- Add theme option
	- Updated languages file
	-------------------------------
	Updated details:
		- Updated "functions.php"
		- Updated "header.php"
		- Updated "class-tgm-plugin-activation.php"
		- Updated "woocommerce/myaccount/my-orders.php"
		- Updated "woocommerce/content-product.php"
		- Updated "header-first.php;header-second.php;header-third.php;header-error.php"
		- Updated "plugins/roadthemes-helper.zip"
		- Updated "theme-config.php"
		- Updated "languages" folder
	-------------------------------